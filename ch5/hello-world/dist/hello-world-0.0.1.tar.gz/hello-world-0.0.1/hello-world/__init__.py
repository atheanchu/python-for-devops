from main import say_hello

say_hello()
